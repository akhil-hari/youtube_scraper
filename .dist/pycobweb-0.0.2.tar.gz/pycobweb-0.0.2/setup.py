# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['pycobweb',
 'pycobweb.bot',
 'pycobweb.cli',
 'pycobweb.http',
 'pycobweb.schema',
 'pycobweb.services',
 'pycobweb.services.builtin',
 'pycobweb.services.builtin.data_store',
 'pycobweb.util']

package_data = \
{'': ['*'], 'pycobweb.cli': ['templates/*']}

install_requires = \
['GitPython>=3.1.27,<4.0.0',
 'commentjson>=0.9.0,<0.10.0',
 'httpx[socks]>=0.22.0,<0.23.0',
 'lxml>=4.8.0,<5.0.0',
 'poetry>=1.1.13,<2.0.0',
 'reactivex>=4.0.0,<5.0.0',
 'tomli-w>=1.0.0,<2.0.0']

entry_points = \
{'console_scripts': ['pycobweb = pycobweb.main:frontend']}

setup_kwargs = {
    'name': 'pycobweb',
    'version': '0.0.2',
    'description': 'Python implimentation of cobweb',
    'long_description': None,
    'author': 'Akhil H Nair',
    'author_email': 'aklhnrpm@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<3.11',
}


setup(**setup_kwargs)
