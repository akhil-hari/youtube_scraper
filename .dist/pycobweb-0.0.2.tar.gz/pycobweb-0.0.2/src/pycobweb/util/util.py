import sys
from importlib import import_module
from pathlib import Path


def snake_case(name):
    name = name.strip(" _")
    name = name.lower()
    name = name.replace(" ", "_")
    return name


def pascal_case(name):
    name = name.strip(" _")
    name = name.title()
    name = name.replace(" ", "")
    name = name.replace("_", "")
    return name


def train_case(name):
    name = name.strip(" _")
    name = name.lower()
    name = name.replace(" ", "-")
    name = name.replace("_", "-")
    return name


def locate_config(current_location, filename, project_root=None, file=True):
    file_location = current_location.joinpath(filename)
    if file_location.exists():
        return file_location if file else current_location
    else:
        if (
            current_location == current_location.parent
            or current_location == project_root
        ):
            return None
        else:
            return locate_config(current_location.parent, filename, file=file)


def import_by_path(name, path, project_root=Path(".")):
    # spec = importlib.util.spec_from_file_location(name, path)
    # module = importlib.util.module_from_spec(spec)
    # sys.modules[spec.name] = module
    # spec.loader.exec_module(module)
    print(sys.path)
    relative_path = path.relative_to(project_root / "src")
    relative_module = str(relative_path.parent).replace("/", ".")
    print(relative_module)
    sys.path.insert(0, str(project_root))
    print(sys.path)
    module = import_module(f"{relative_module}.{name}")
    del sys.path[0]
    # module.main()
    return module


def pycobweb_test():
    print("pycobweb imports will work")
