from pycobweb.services.builtin.cache import Cache
from pycobweb.services.builtin.data_store.data_store import DataStore
from pycobweb.services.builtin.locate_configs import LocateConfigs
from pycobweb.services.builtin.request_processor import RequestProcessor
from pycobweb.services.builtin.settings import Settings

essential_services = [
    ("LocateConfigs", LocateConfigs),
    ("Settings", Settings),
    ("Cache", Cache),
    ("DataStore", DataStore),
    ("RequestProcessor", RequestProcessor),
]
