import traceback
from concurrent.futures import ThreadPoolExecutor

from httpx import RequestError, delete, get, head, options, patch, post, put
from reactivex.subject import Subject

from pycobweb.http.request import Request, Response
from pycobweb.schema import NormalSchema
from pycobweb.services import service
from pycobweb.services.builtin.cache import Cache
from pycobweb.services.builtin.data_store import DataStore
from pycobweb.services.builtin.settings import Settings

methods_dict = {
    "get": get,
    "put": put,
    "head": head,
    "post": post,
    "options": options,
    "patch": patch,
    "delete": delete,
}
rejected_schema = NormalSchema(
    ["method", "url", "meta", "last_error"], "__rejected_urls__"
)


class ResponseError(Exception):
    pass


@service
class RequestProcessor:
    def __init__(self, settings: Settings, cache_service: Cache, data_store: DataStore):
        self.cache = cache_service
        self.MAX_RETRY = settings.MAX_RETRY
        self.THREADS = settings.THREADS
        self.pool = Subject()
        self.data_store = data_store
        self.__queue__ = []
        self.__thread_pool__ = ThreadPoolExecutor(
            self.THREADS, thread_name_prefix="pycobweb:processor:thread"
        )
        self.pool.subscribe(on_next=self.__process_on_thread)

    def __process_on_thread(self, item):
        future = self.__thread_pool__.submit(self.__process_next, item)
        self.__queue__.append(future)

    @property
    def queue(self):
        self.__queue__ = list(filter(lambda x: not x.done(), self.__queue__))
        return self.__queue__

    def __retry(self, request, reason=""):
        if request.retry < self.MAX_RETRY:
            request.retry += 1
            self.pool.on_next(request)
        else:
            reject_dict = {
                "method": request.method,
                "url": request.url,
                "meta": request.meta,
                "last_error": reason,
            }
            self.data_store.store(rejected_schema(reject_dict))
            print(f"\033[41mRejecting url {request.url}\033[0m")

    def __process_next(self, push_obj):
        if isinstance(push_obj, Response):
            reason = push_obj.error
            push_obj.error = None
            self.__process_error(push_obj, reason)
            return
        self.__process_request(push_obj)

    def __process_request(self, request_obj):

        request = (
            request_obj if isinstance(request_obj, Request) else Request(request_obj)
        )
        callback = request.callback
        options = request.options
        request_url = request.url
        if not request_url:
            raise BaseException("no url passed")
        if request.retry:
            print(
                f"Retrying url [{request.retry}]: \033[92m[{request.method}]\033[0m \033[94m{request.url}\033[0m"
            )
        else:
            print(
                f"Fetching url: \033[92m[{request.method}]\033[0m \033[94m{request.url}\033[0m"
            )

        cache_hit = self.cache.get_from_cache(request)
        if cache_hit:
            print(
                f"\033[92mCache Ht for\033[0m: \033[92m[{request.method}]\033[0m {request_url}"
            )
            raw_response = cache_hit
            callback(
                Response(raw_response=raw_response, meta=request.meta, request=request)
            )
            return
        try:
            method_function = methods_dict.get(request.method)
            raw_response = method_function(**request.request)
            callback_status = callback(
                Response(raw_response=raw_response, meta=request.meta, request=request)
            )
            if not options.get("no_cache") and callback_status:
                self.cache.add_to_cache(request, raw_response)
            print(
                f"Finished processing: \033[92m[{request.method}]\033[0m \033[94m{request.url}\033[0m"
            )
        except RequestError as error:
            print(
                f"\033[41mREQUEST ERROR while processing [{request.method}] {request.url}  Due to:    {error}\033[0m"
            )
            self.__retry(request, reason=error)
        except KeyboardInterrupt:
            print("\n\033[92mCrawling Completed.\033[0m")
            exit()
        except Exception as error:
            print(f"\033[91mERROR Due to:    {error}\033[0m")
            print(traceback.format_exc())
            self.__retry(request, reason=error)

    def __process_error(self, response, reason=None):
        request = response.request
        self.__retry(request, reason=reason)

    def send(self, request_obj):
        self.pool.on_next(request_obj)

    def error(self, response, reason):
        print(f"\033[41mRESPONSE ERROR Due to:    {reason}\033[0m")
        response.error = reason if reason else "unknown error"
        self.pool.on_next(response)
        return False
