from pycobweb.services import service
from pycobweb.services.builtin.locate_configs import LocateConfigs


@service
class Settings:
    MAX_RETRY = 20
    CACHE_EXPIRE = {"days": 7}
    THREADS = 6
    DATASTORE_CONFIG = {
        "buffer_stratagy": "TimeBuffer",
        "time_buffer_intervel": 5,
        "count_buffer_intervel": 10,
        "count_buffer_threshold": 10,
    }

    def __init__(self, locate_configs: LocateConfigs):
        pass
