from csv import QUOTE_ALL, DictWriter

from pycobweb.services import service
from pycobweb.services.builtin.settings import Settings
from pycobweb.util.buffer import CountBuffer, TimeBuffer

# from threading import current_thread


@service
class DataStore:
    def __init__(self, settings: Settings):
        data_store_config = settings.DATASTORE_CONFIG
        buffer_stratagy = data_store_config.get("buffer_stratagy")
        self.buffer = TimeBuffer() if buffer_stratagy == "TimeBuffer" else None
        self.buffer = CountBuffer() if buffer_stratagy == "CountBuffer" else self.buffer
        self.buffer.get_listener(self.__iterate_and_store)
        self.data_format = "csv"
        self.datasets = {}
        locate_configs = self.handler.get_service("LocateConfigs")
        self.data_folder = locate_configs.data_root
        if self.data_folder:
            self.data_folder.mkdir(parents=True, exist_ok=True)

    def print_items(self, items):
        print(items[0])

    def store(self, schema_and_name):
        self.buffer.push(schema_and_name)

    def __store_backend(self, data_and_name):
        data = data_and_name[0]
        name = data_and_name[1]
        # rewrite = data_and_name[2]

        mode = "a"
        fields = list(data.keys())
        if not self.datasets.get(name):
            self.datasets[name] = list(data.keys())
            mode = "w"
        if self.data_folder:
            with open(
                self.data_folder / f"{name}.{self.data_format}", mode
            ) as store_file:
                writer = DictWriter(store_file, fieldnames=fields, quoting=QUOTE_ALL)
                if mode == "w":
                    writer.writeheader()
                writer.writerow(data)
        else:
            print("no data_folder defined ")

    def __no_rewite_file(self, name, count=0):
        name = name if count == 0 else f"{name}_{count}"
        if self.data_folder / f"{name}.{self.data_format}".exists():
            count += 1
            return self.__no_rewite_file(name, count=count)
        else:
            return name

    def __iterate_and_store(self, item):
        if isinstance(item, list):
            for single_item in item:
                self.__store_backend(single_item)
        else:
            self.__store_backend(item)
