from concurrent.futures import ThreadPoolExecutor

from pycobweb.services import service


@service
class ThreadPool:
    __thread__pool__ = ThreadPoolExecutor(10)
