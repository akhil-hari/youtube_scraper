import os
from inspect import getmembers

from pycobweb.util import import_by_path


def service(input_class):
    class_init = input_class.__init__
    __dependencies__ = []

    annotations = (
        class_init.__annotations__ if hasattr(class_init, "__annotations__") else {}
    )
    for service in annotations:
        __dependencies__.append(annotations[service].__qualname__)
    input_class.__dependencies__ = __dependencies__
    input_class.__is_service__ = True

    return input_class


def isservice(class_object):
    if hasattr(class_object, "__is_service__") and class_object.__is_service__:
        return True
    else:
        return False


def list_service(services_folder, project_root):
    services = []
    if not (services_folder and services_folder.exists):
        return services
    for file in os.listdir(services_folder):
        file_path = services_folder.joinpath(file)
        if not file_path.is_dir() and file.endswith(".py"):
            module_name = file.replace(".py", "").strip()
            module = import_by_path(module_name, file_path, project_root=project_root)
            services.extend(getmembers(module, isservice))
    return services
