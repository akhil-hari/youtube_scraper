from os import getcwd
from pathlib import Path
from sys import argv

import pycobweb.cli.cli as cli
from pycobweb.cli.generate_bot import generate_bot
from pycobweb.cli.generate_main import generate_main
from pycobweb.cli.generate_poetry import generate_poetry
from pycobweb.cli.generate_project import generate_project
from pycobweb.cli.generate_settings import generate_settings
from pycobweb.util import snake_case


def frontend():
    args = argv[1:]
    current_path = Path(getcwd())
    if args and args[0] == "new":
        cli.print_cli_msg()
        project_name = snake_case(args.pop(1))
        project_path = current_path / project_name
        try:
            project_path.mkdir()
        except Exception as error:
            print(error)
            exit()
        keys = ["description", "repo", "author", "email", "website"]
        project_dict = {"name": project_name, "platform": "pycobweb"}
        for key in keys:
            project_dict[key] = input(f"{key}:\t")
        generate_project(project_dict, project_path)
        (project_path / f"src/{project_name}/services").mkdir(parents=True)
        (project_path / f"src/{project_name}/callbacks").mkdir(parents=True)
        (project_path / f"src/{project_name}/utils").mkdir(parents=True)
        (project_path / f"src/{project_name}/schemas").mkdir(parents=True)
        generate_settings(project_path)
        generate_bot(project_name, (project_path / f"src/{project_name}"))
        generate_main(project_name, (project_path / f"src/{project_name}"))
        generate_poetry(
            project_name,
            project_dict.get("description"),
            project_dict.get("author"),
            project_dict.get("email"),
            project_path,
        )
    elif args and args[0] == "run":
        cli.runner()
    else:
        print("feature not yet implimented")
