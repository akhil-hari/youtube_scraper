from importlib import import_module
from os import getcwd
from pathlib import Path
from sys import path

import commentjson as json

import pycobweb
from pycobweb.util import locate_config


def print_cli_msg():
    print(f"<< \33[92mPycobweb\33[0m -> {pycobweb.__version__} >>")


def runner():
    project_root = locate_config(Path(getcwd()), "cobweb.project.jsonc", file=False)
    if project_root:
        project_file = project_root / "cobweb.project.jsonc"
        with open(project_file) as project_object:
            project = json.load(project_object)
            project_name = project.get("name")
        path.insert(0, str(project_root / "src"))
        bot_module = import_module(f"{project_name}.main")
        del path[0]
        bot_module.main()
