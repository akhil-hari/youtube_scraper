from pathlib import Path

from pycobweb.util import snake_case

name_regex = r"^[a-zA-Z_\s][\w\s]+$"


function_template = """
@callback
def {function_name}(bot, response):
    print(response.text_data)
"""


def generate_callback(raw_name: str, function_names: list, out_path: Path):
    template_folder = Path(__file__).parent.joinpath("templates")
    callback_template = open(template_folder.joinpath("callback_template")).read()
    service_name_snake = snake_case(raw_name)
    for function_name in function_names:
        function_snippet = function_template.format(
            function_name=snake_case(function_name)
        )
        callback_template = f"{callback_template}{function_snippet}"
    out_file = out_path.joinpath(f"{service_name_snake}.py")
    open(out_file, "w").write(callback_template)
