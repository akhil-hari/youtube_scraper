from pathlib import Path

import commentjson as json

from pycobweb.util import snake_case

comment = """
//This file marks the projects root directory,it contains
//project information
"""


def generate_project(params: dict, path: Path):
    if path.is_dir():
        name = params.get("name")
        name = snake_case(name)
        repo = params.get("repo")
        author = params.get("author")
        email = params.get("email")
        website = params.get("website")
        description = params.get("description")
        platform = "python(Pycobweb)"
        project_dict = {
            "name": name,
            "description": description,
            "repo": repo,
            "author": author,
            "email": email,
            "website": website,
            "platform": platform,
        }
        project_json = json.dumps(project_dict, indent=3)
        project_json = comment + project_json
        open(path.joinpath("cobweb.project.jsonc"), "w").write(project_json)
