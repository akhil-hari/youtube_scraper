import re
from pathlib import Path

from pycobweb.util import pascal_case


def generate_main(raw_name, out_path):
    template_folder = Path(__file__).parent.joinpath("templates")
    main_template = open(template_folder.joinpath("main_template")).read()
    bot_name_pascal = pascal_case(re.sub(r"\d", "", raw_name))
    output = main_template.format(bot_class_name=bot_name_pascal)
    out_file = out_path.joinpath("main.py")
    open(out_file, "w").write(output)
