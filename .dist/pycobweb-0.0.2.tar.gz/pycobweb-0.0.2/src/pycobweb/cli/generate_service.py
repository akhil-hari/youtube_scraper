from pathlib import Path

from pycobweb.util import pascal_case, snake_case

name_regex = r"^[a-zA-Z_\s][\w\s]+$"


def generate_service(raw_name: str, out_path: Path):
    template_folder = Path(__file__).parent.joinpath("templates")
    service_template = open(template_folder.joinpath("service_template")).read()
    service_name_snake = snake_case(raw_name)
    service_name_pascal = pascal_case(raw_name)
    output = service_template.format(
        service_name_snake=service_name_snake, service_name_pascal=service_name_pascal
    )
    out_file = out_path.joinpath(f"{service_name_snake}.py")
    open(out_file, "w").write(output)
