import pycobweb.cli.cli as cli

__all__ = ["cli"]
