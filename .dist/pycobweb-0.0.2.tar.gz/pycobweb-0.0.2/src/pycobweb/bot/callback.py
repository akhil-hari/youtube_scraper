import os
from inspect import getmembers

from pycobweb.util import import_by_path


def callback(func):
    def wrapper(bot, response):
        return_value = func(bot, response)
        if return_value is None:
            return True
        return return_value

    wrapper.__is_callback__ = True

    return wrapper


def iscallback(callback_fn):
    if hasattr(callback_fn, "__is_callback__") and callback_fn.__is_callback__:
        return True
    else:
        return False


def list_callback(callbacks_folder, project_root):
    callbacks = []
    if not (callbacks_folder and callbacks_folder.exists):
        return callbacks
    for file in os.listdir(callbacks_folder):
        file_path = callbacks_folder / file
        if not file_path.is_dir() and file.endswith(".py"):
            module_name = file.replace(".py", "").strip()
            module = import_by_path(module_name, file_path, project_root=project_root)
            callbacks.extend(getmembers(module, iscallback))
    return callbacks
