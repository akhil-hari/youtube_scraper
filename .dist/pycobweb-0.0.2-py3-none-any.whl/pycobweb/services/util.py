class CyclicReferenceError(Exception):
    pass


def order_service(graph):
    def get_edges(key, stack=None, graph=graph):
        stack = stack if stack else []
        edges = graph.get(key)
        stack.append(key)
        cycle = False
        edge_tuple = set()
        for edge_key in edges:
            edge_tuple.add((key, edge_key))
            if edge_key not in stack:
                edge_tuple = edge_tuple.union(get_edges(edge_key, stack.copy()))
            else:
                stack.append(edge_key)
                cycle = True
                break

        if edges == []:
            return edge_tuple
        elif cycle:
            print(" -> ".join(stack))
            raise CyclicReferenceError(f"{stack[-2]} cyclicaly references {stack[-1]}")
        return edge_tuple

    # edge_set = set()
    edge_dict = dict()
    key_list = list(graph)
    for key in graph:
        edge_dict[key] = list(set(map(lambda x: x[1], get_edges(key))))
    key_list.sort(key=lambda x: len(edge_dict[x]))

    def order_keys(key, edge_dict=edge_dict):
        key_index = key_list.index(key)
        for edge_key in edge_dict[key]:
            edge_key_index = key_list.index(edge_key)
            if edge_key_index > key_index:
                key_list.pop(edge_key_index)
                key_list.insert(edge_key, key_index)
                key_index = key_list.index(key)

    for key in key_list:
        order_keys(key)
    return key_list


def get_service_graph(services):
    graph = {}
    for service in services:
        service_class = service[1]
        service_name = service[0]
        graph[service_name] = service_class.__dependencies__
    return graph
