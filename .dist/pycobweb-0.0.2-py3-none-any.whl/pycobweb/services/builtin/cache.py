import json
from datetime import datetime, timedelta
from hashlib import sha256

from pycobweb.services import service
from pycobweb.services.builtin.locate_configs import LocateConfigs
from pycobweb.services.builtin.settings import Settings


class CacheRawResponse:
    def __init__(self, content):
        self.text = content.decode("utf-8")
        self.content = content
        self.status_code = 304
        self.is_cache = True

    def json(self):
        return json.loads(self.text)


@service
class Cache:
    def __init__(self, locate_configs: LocateConfigs, settings: Settings):
        # self.cache_path = Path(__file__).parent.joinpath("cache")
        self.cache_path = locate_configs.cache_root
        self.cache_path.mkdir(parents=True, exist_ok=True)
        CACHE_EXPIRE = settings.CACHE_EXPIRE
        self.update_timedelta = timedelta(**CACHE_EXPIRE)

    def get_from_cache(self, request):
        unique_sha = self.__unique_sha(request)
        unique_cache_path = self.cache_path / f"{unique_sha}"
        if unique_cache_path.exists():
            cache_file_stats = unique_cache_path.stat()
            modified = datetime.fromtimestamp(cache_file_stats.st_mtime)
            now = datetime.now()
            if self.update_timedelta < (now - modified):
                print("\033[33mCache Expired!\033[0m")
                return
            with open(unique_cache_path, "rb") as cache_file:
                content = cache_file.read()
                return CacheRawResponse(content)

    def add_to_cache(self, request, response):
        unique_sha = self.__unique_sha(request)
        unique_cache_path = self.cache_path / f"{unique_sha}"
        with open(unique_cache_path, "wb") as cache_file:
            cache_file.write(response.content)

    def __unique_sha(self, request):
        unique_dict = {
            "url": request.url,
            "method": request.method,
            "data": request.request.get("data"),
            "params": request.request.get("params"),
            "json": request.request.get("json"),
        }
        unique_text = json.dumps(unique_dict)
        unique_sha = sha256(unique_text.encode()).hexdigest()
        return unique_sha
