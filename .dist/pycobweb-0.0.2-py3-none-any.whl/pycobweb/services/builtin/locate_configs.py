from os import getcwd
from pathlib import Path

import commentjson as json

from pycobweb.services import service
from pycobweb.util import locate_config


@service
class LocateConfigs:
    def __init__(self):
        self.project_root = locate_config(
            Path(getcwd()), "cobweb.project.jsonc", file=False
        )
        with open(self.project_root / "cobweb.project.jsonc") as project_file:
            project = json.load(project_file)
        self.services_root = None
        self.callbacks_root = None
        self.project_name = project.get("name")
        self.settings = self.project_root / "settings.jsonc"
        if self.project_root:
            self.data_root = self.project_root / ".data"
            self.cache_root = self.project_root / ".cache"
            self.services_root = self.project_root / f"src/{self.project_name}/services"
            self.callbacks_root = (
                self.project_root / f"src/{self.project_name}/callbacks"
            )
