from pycobweb.services.builtin.data_store.data_store import DataStore

__all__ = ["DataStore"]
