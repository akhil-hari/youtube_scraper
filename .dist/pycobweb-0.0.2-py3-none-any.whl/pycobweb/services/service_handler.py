from pycobweb.services.builtin import essential_services
from pycobweb.services.service import list_service
from pycobweb.services.util import get_service_graph, order_service


class ServiceError(Exception):
    pass


class ServiceHandler:
    active_services = {}
    not_found_services = []
    other_services = []  # [(<service_name>, ServiceClass)]

    def __init__(self):
        dependency_graph_essential = get_service_graph(essential_services)
        service_load_order_essential = order_service(dependency_graph_essential)
        self.__plug_service_list(service_load_order_essential, essential_services)
        locate_configs = self.get_service("LocateConfigs")
        self.other_services.extend(
            list_service(locate_configs.services_root, locate_configs.project_root)
        )
        dependency_graph_other = get_service_graph(self.other_services)
        service_load_order_other = order_service(dependency_graph_other)
        self.__plug_service_list(service_load_order_other, self.other_services)

    def __plug_service_list(self, service_load_order, service_list):
        service_dict = dict(service_list)
        for service_name in service_load_order:
            service_class = service_dict[service_name]
            self.__plug_service(service_class)

    def get_service(self, service_name):
        service = self.active_services.get(service_name)
        if service:
            return service
        else:
            raise ServiceError(f"no service available with name {service_name}")

    def __plug_service(self, service_class):
        service_name = service_class.__qualname__
        dependencies = service_class.__dependencies__

        dependency_classes = []
        for dependency in dependencies:
            try:
                dependency_class = self.get_service(dependency)
                dependency_classes.append(dependency_class)

            except ServiceError:
                self.not_found_services.append(dependency)
        service_class.handler = property(fget=lambda x: self)
        service = service_class(*dependency_classes)
        self.active_services[service_name] = service
