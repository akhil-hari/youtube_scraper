import json
from copy import deepcopy

from lxml import html

# with open("headers.json") as headers_file:
#     headers = json.load(headers_file)


class Request:
    def __init__(self, request_dict):
        self.meta = deepcopy(request_dict.pop("meta", {}))

        def no_callback(response):
            return response

        self.callback = request_dict.pop("callback", no_callback)
        self.method = request_dict.pop("method", "get").lower()
        self.request = request_dict
        self.url = request_dict.get("url", "")
        self.backend = request_dict.pop("backend", "httpx<python>")
        self.retry = 0
        options_list = [("no_cache", False)]
        self.options = {
            option[0]: self.request.pop(option[0], option[1]) for option in options_list
        }
        # if not self.request.get("headers"):
        #     self.request["headers"] = headers
        def json(self, string_output=False):
            json_dict = {
                "meta": self.meta,
                "callback": self.callback.__name__.strip("<>"),
                "method": self.method,
                "request": self.request,
                "url": self.url,
                "backend": self.backend,
                "retry": self.retry,
                "options": self.options,
            }
            if string_output:
                return json.dumps(json_dict)
            return json_dict


class Response:
    def __init__(self, raw_response, request, meta):
        self.data = raw_response.content
        self.text_data = raw_response.text
        # self.json = raw_response.json
        self.status = raw_response.status_code
        self.url = raw_response.url
        self.raw_response = raw_response
        self.meta = meta
        self.request = request
        self.error = None
        if hasattr(raw_response, "is_cache"):
            self.is_cache = raw_response.is_cache
        else:
            self.is_cache = False

        try:
            self.html_parser = html.fromstring(self.data)
        except KeyboardInterrupt:
            print("\n\033[92mCrawling Completed.\033[0m")
            exit()
        except BaseException:
            self.html_parser = None

    def json(self):
        try:
            json_data = json.loads(self.data)
            return json_data
        except Exception:
            return None
