from pycobweb.main import frontend

__version__ = "0.0.2"

__all__ = ["__version__"]
__main__ = frontend
