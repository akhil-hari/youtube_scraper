class DataError(Exception):
    pass


class NormalSchema:
    def __init__(self, schema: list, schema_name: str):
        self.schema = schema
        self.name = schema_name

    def __call__(self, data_dict: dict):
        emited_dict = {}
        for key in self.schema:
            if key not in data_dict:
                raise DataError(f"'{key}' not found in data")
            else:
                emited_dict[key] = data_dict[key]
        return emited_dict, self.name
