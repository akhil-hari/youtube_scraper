from time import sleep
from types import MethodType

from pycobweb.bot.callback import list_callback
from pycobweb.services import ServiceHandler


class BotError(Exception):
    pass


# def wait_for_all(queue):
#     print()
#     if wait(queue):
#         if wait(queue, timeout=5).not_done:
#             wait_for_all(queue)
#     return True


def wait_for_all(request_processor):
    while request_processor.queue:
        sleep(5)

    return True


class Bot:
    __service_handler__ = ServiceHandler()
    get_service = __service_handler__.get_service
    __request_processor__ = get_service("RequestProcessor")
    # queue = __request_processor__.queue
    __data_store__ = get_service("DataStore")
    settings = get_service("Settings")
    send = __request_processor__.send
    error = __request_processor__.error
    store = __data_store__.store
    callbacks = []

    def __new__(cls, *args, **kwargs):
        locate_configs = cls.get_service("LocateConfigs")
        export_object = super(Bot, cls).__new__(cls)
        found_callbacks_list = list_callback(
            locate_configs.callbacks_root, locate_configs.project_root
        )
        for callback in found_callbacks_list:
            callback_name = callback[0]
            callback_method = MethodType(callback[1], export_object)
            setattr(export_object, callback_name, callback_method)
        return export_object

    def start(bot):
        if not hasattr(bot, "entry_point"):
            raise BotError("Entry point not defined")
        bot.entry_point()
        if wait_for_all(bot.__request_processor__):
            bot.__request_processor__.__thread_pool__.shutdown()
            data_store_buffer = bot.__data_store__.buffer
            data_store_buffer.wait_for_timer()
        bot.end()

    def end(bot):
        print("\n\033[92mCrawling Completed.\033[0m")

        print("\n\033[92mCrawling Completed.\033[0m")
