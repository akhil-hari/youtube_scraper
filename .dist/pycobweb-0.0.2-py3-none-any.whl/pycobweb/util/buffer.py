from copy import deepcopy
from threading import Timer

from reactivex.subject import Subject


class TimeBuffer:
    def __init__(self, intervel: int = 3):
        self.intervel = intervel if intervel and intervel > 0 else None
        if not self.intervel:
            raise ValueError("Intervel must be  positive integer")
        self.waiting = False
        self.buffer_subject = Subject()
        self.buffer_list = []
        self.__timer = None

    def push(self, item):
        if isinstance(item, list):
            for single_item in item:
                self.buffer_list.append(single_item)
        else:
            self.buffer_list.append(item)
        if not self.waiting:
            self.__timer = Timer(self.intervel, self.__output)
            self.__timer.start()
            self.waiting = True

    def __output(self):
        push_item = deepcopy(self.buffer_list)
        self.buffer_list.clear()
        self.buffer_subject.on_next(push_item)
        self.waiting = False
        self.__timer = None

    def get_listener(self, callback):
        return self.buffer_subject.subscribe(on_next=callback)

    def wait_for_timer(self):
        if self.__timer:
            self.__timer.join()


class CountBuffer:
    def __init__(self, threshold: int, intervel: int = None):
        self.intervel = intervel if intervel and intervel > 0 else None
        self.threshold = threshold
        self.waiting = False
        self.buffer_subject = Subject()
        self.buffer_list = []
        self.__timer = None

    def push(self, item):
        if isinstance(item, list):
            for single_item in item:
                self.buffer_list.append(single_item)
        else:
            self.buffer_list.append(item)
        if not self.waiting and self.intervel:
            self.__timer = Timer(self.intervel, self.__output)
            self.__timer.start()
            self.waiting = True
        if len(self.buffer_list) == self.threshold:
            if self.waiting:
                self.__timer.cancel()
                self.waiting = False
                self.__timer = None
            self.__output()

    def __output(self):
        push_item = deepcopy(self.buffer_list)
        self.buffer_list.clear()
        self.buffer_subject.on_next(push_item)
        self.waiting = False
        self.__timer = None

    def get_listener(self, callback):
        return self.buffer_subject.subscribe(on_next=callback)

    def wait_for_timer(self):
        if self.__timer:
            self.__timer.join()
