import tomli_w as toml


def generate_poetry(raw_name, description, author, email, path):
    print(path)
    authors = [f"{author} <{email}>"] if author and email else []
    pyproject_dict = {
        "tool": {
            "poetry": {
                "name": raw_name,
                "version": "0.0.1",
                "description": description,
                "authors": authors,
                "license": "none",
                "dependencies": {
                    "python": ">=3.9,<3.11",
                    "pycobweb": {"path": ".dist/pycobweb-0.0.1-py3-none-any.whl"},
                },
                "dev-dependencies": {},
            }
        },
        "build-system": {
            "requires": ["poetry-core>=1.0.0"],
            "build-backend": "poetry.core.masonry.api",
        },
    }
    poetry_dict = {"virtualenvs": {"in-project": True}}
    toml.dump(pyproject_dict, open(path / "pyproject.toml", "wb"))
    toml.dump(poetry_dict, open(path / "poetry.toml", "wb"))
