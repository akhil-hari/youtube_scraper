import re
from pathlib import Path

from pycobweb.util import pascal_case, snake_case


def generate_bot(raw_name, out_path):
    template_folder = Path(__file__).parent.joinpath("templates")
    bot_template = open(template_folder.joinpath("bot_template")).read()
    bot_name_snake = snake_case(raw_name)
    bot_name_pascal = pascal_case(re.sub(r"\d", "", raw_name))
    output = bot_template.format(
        bot_class_name=bot_name_pascal, bot_name_snake=bot_name_snake
    )
    out_file = out_path.joinpath("bot.py")
    open(out_file, "w").write(output)
