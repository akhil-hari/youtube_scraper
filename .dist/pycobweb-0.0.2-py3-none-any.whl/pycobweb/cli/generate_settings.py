from pathlib import Path


def generate_settings(out_path: Path):
    template_folder = Path(__file__).parent.joinpath("templates")
    settings_template = open(template_folder.joinpath("settings_template")).read()
    out_file = out_path.joinpath("settings.jsonc")
    open(out_file, "w").write(settings_template)
